from django.shortcuts import render
from googletrans import Translator

def translate_text(request):
    if request.method == 'POST':
        text = request.POST.get('text', '')
        target_lang = request.POST.get('target_lang', 'kn')
        
        try:
            translator = Translator()
            translated = translator.translate(text, dest=target_lang)
            translated_text = translated.text
        except Exception as e:
            translated_text = "Error in translation. Please try again."
    else:
        text = ''
        translated_text = ''
        target_lang = 'kn'
    
    context = {
        'original_text': text,
        'translated_text': translated_text,
        'selected_lang': target_lang
    }
    return render(request, 'translator/translate.html', context)